//
//  ViewController.swift
//  Tweetgram
//
//  Created by zappycode on 3/17/18.
//  Copyright © 2018 Nick Walter. All rights reserved.
//

import UIKit
import Swifter

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let swifter = Swifter(consumerKey: "NmuhxvAuAf3JMc0CobtRwle8N", consumerSecret: "dnaxsBGTBQ5J1ZUakNNXExsY71NUV4uj53eCNudnb1ozEKaHAq")
        
        if let url = URL(string: "Tweetgram://hello") {
            swifter.authorize(with: url, presentFrom: self, success: { (token, response) in
                swifter.getHomeTimeline(count: 50, sinceID: nil, maxID: nil, trimUser: nil, contributorDetails: nil, includeEntities: nil, success: { (json) in
                    print(json)
                }, failure: { (error) in
                    print("error")
                })
            }, failure: { (error) in
                print("we had an error")
            })
        }
        
        
    }

}

