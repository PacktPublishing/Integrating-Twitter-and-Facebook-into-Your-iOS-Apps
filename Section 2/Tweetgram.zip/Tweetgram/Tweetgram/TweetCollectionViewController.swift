//
//  TweetCollectionViewController.swift
//  Tweetgram
//
//  Created by zappycode on 3/17/18.
//  Copyright © 2018 Nick Walter. All rights reserved.
//

import UIKit
import Swifter
import SDWebImage

class TweetCollectionViewController: UICollectionViewController, UICollectionViewDelegateFlowLayout {
    
    @IBOutlet weak var loginButton: UIBarButtonItem!
    
    var imagesURLs : [String] = []
    var tweetURLs : [String] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
    }
    
    @IBAction func loginTapped(_ sender: Any) {
        
        if loginButton.title == "Logout" {
            // Logout Code
            loginButton.title = "Login"
            imagesURLs = []
            tweetURLs = []
            collectionView?.reloadData()
        } else {
            // Login Code
            loginButton.title = "Logout"
            let swifter = Swifter(consumerKey: "NmuhxvAuAf3JMc0CobtRwle8N", consumerSecret: "dnaxsBGTBQ5J1ZUakNNXExsY71NUV4uj53eCNudnb1ozEKaHAq")
            
            if let url = URL(string: "Tweetgram://hello") {
                swifter.authorize(with: url, presentFrom: self, success: { (token, response) in
                    
                    
                    swifter.getHomeTimeline(count: 200, sinceID: nil, maxID: nil, trimUser: nil, contributorDetails: nil, includeEntities: nil, tweetMode: .extended, success: { (json) in
                        self.parseJSON(json: json)
                    }, failure: { (error) in
                        print("error")
                    })
                }, failure: { (error) in
                    print("we had an error")
                })
            }
        }
    }
    
    func parseJSON(json:JSON) {
        
        if let tweets = json.array {
            for tweet in tweets {
                var retweeted = false
                if let medias = tweet["retweeted_status"]["extended_entities"]["media"].array {
                    retweeted = true
                    processURLs(medias: medias)
                }
                
                if retweeted == false {
                    if let medias = tweet["extended_entities"]["media"].array {
                        processURLs(medias: medias)
                    }
                }
            }
        }
        
        collectionView?.reloadData()
        
    }
    
    func processURLs(medias : [JSON]) {
        for media in medias {
            if let mediaURL = media["media_url_https"].string {
                imagesURLs.append(mediaURL)
            }
            if let expandedURL = media["expanded_url"].string {
                tweetURLs.append(expandedURL)
            }
        }
    }
    
    override func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    override func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imagesURLs.count
    }
    
    override func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        if let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "tweetcell", for: indexPath) as? TweetCell {
            
            let url = URL(string: imagesURLs[indexPath.row])
            cell.tweetImageView.sd_setImage(with: url, completed: nil)
            cell.tweetImageView.contentMode = .scaleAspectFill
            
            return cell
        }
        
        return UICollectionViewCell()
    }
    
    override func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if let url = URL(string: tweetURLs[indexPath.row]) {
            UIApplication.shared.open(url, options: [:], completionHandler: nil)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionView.frame.size.width/2, height: collectionView.frame.size.width/2)
    }
}

class TweetCell : UICollectionViewCell {
    
    @IBOutlet weak var tweetImageView: UIImageView!
}
