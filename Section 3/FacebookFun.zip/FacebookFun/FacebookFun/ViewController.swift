//
//  ViewController.swift
//  FacebookFun
//
//  Created by zappycode on 3/19/18.
//  Copyright © 2018 Nick Walter. All rights reserved.
//

import UIKit
import FBSDKLoginKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()

        
        let loginButton = FBSDKLoginButton()
        loginButton.readPermissions = ["user_likes"]
        loginButton.center = view.center
        view.addSubview(loginButton)
        
        FBSDKGraphRequest(graphPath: "me?fields=id,name,likes", parameters: [:]).start { (connection, result, error) in
            print("RESULTS: \(result)")
        }

    }
    
}

